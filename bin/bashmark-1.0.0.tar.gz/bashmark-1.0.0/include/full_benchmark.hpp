#pragma once

void run_full_benchmark();
