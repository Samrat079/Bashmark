// include/gpu_benchmark.hpp
#ifndef GPU_BENCHMARK_HPP
#define GPU_BENCHMARK_HPP

// Function declaration for GPU benchmark (no parameters needed)
void run_gpu_benchmark();

#endif // GPU_BENCHMARK_HPP