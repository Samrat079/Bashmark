#pragma once

void run_multi_core_benchmark(int threadCount = 0);
