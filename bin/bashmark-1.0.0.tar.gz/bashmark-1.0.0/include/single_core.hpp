#pragma once

void run_single_core_benchmark();
